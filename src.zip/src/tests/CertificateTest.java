package tests;

public class CertificateTest {/*
	public static void main(String[] args) {
		MSCAPICertificatesHolder holder = new MSCAPICertificatesHolder();
		holder.getCertificates().forEach( certificate -> {
			System.out.println(certificate.getIssuedTo());
			System.out.println(certificate.getEmailAdress());
			System.out.println(certificate.getIssuedBy());
			System.out.println("---------------------------");
		});
		
	}*/
}
