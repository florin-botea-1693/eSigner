package model.signing.visible;

public enum SignatureImageRenderMode {
	LTR, 
	RTL, 
	TTB, 
	BTT
}
