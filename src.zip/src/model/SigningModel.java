package model;

public abstract class SigningModel {

}
