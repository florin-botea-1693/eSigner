package tests;

public class MSCAPICertificatesHolderTest {
	/*
	public static void main(String[] args) {
		MSCAPICertificatesHolder holder = new MSCAPICertificatesHolder();
		Certificate cert = holder.getCertificates().get(0);
		System.out.println( cert.getIssuedTo() );
		System.out.println( cert.getPrincipal().getName() );
	}
	*/
}
